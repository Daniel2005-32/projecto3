let movimientos = 0;
let tiempo = 0;
let temporizador = null;

window.addEventListener('DOMContentLoaded', () => {
    mostrarMejoresTiempos(); 
});

function inicioJuego() {
    const celdas = [];
    for (let i = 1; i <= 9; i++) {
        const celda = document.getElementById(`parte${i}`);
        celda.replaceWith(celda.cloneNode(true));
        const nuevaCelda = document.getElementById(`parte${i}`);
        nuevaCelda.addEventListener('click', () => moverPieza(i));
        celdas.push(nuevaCelda);
    }

    const contenidos = celdas.map(celda => celda.innerHTML);
    shuffle(contenidos);

    for (let i = 0; i < celdas.length; i++) {
        celdas[i].innerHTML = contenidos[i];
    }

    movimientos = 0;
    tiempo = 0;
    document.getElementById("mensaje").textContent = "¡Piezas mezcladas!";
    document.getElementById("contador-mov").textContent = `Movimientos: ${movimientos}`;
    document.getElementById("contador-tiempo").textContent = `Tiempo: 0 s`;

    if (temporizador) clearInterval(temporizador);
    temporizador = setInterval(() => {
        tiempo++;
        document.getElementById("contador-tiempo").textContent = `Tiempo: ${tiempo} s`;
    }, 1000);
}

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function moverPieza(numCelda) {
    const celdaActual = document.getElementById(`parte${numCelda}`);
    if (!celdaActual || celdaActual.innerHTML.trim() === "") return;

    const celdaVacia = obtenerCeldaVacia();
    if (!celdaVacia) return;

    if (esVecina(numCelda, celdaVacia)) {
        const tmp = celdaActual.innerHTML;
        celdaActual.innerHTML = "";
        celdaVacia.innerHTML = tmp;

        movimientos++;
        document.getElementById("contador-mov").textContent = `Movimientos: ${movimientos}`;

        if (verificarVictoria()) {
            juegoTerminado = true;
            clearInterval(temporizador);
            document.getElementById("mensaje").textContent =
                ` ¡Puzzle completado en ${movimientos} movimientos y ${tiempo} segundos!`;

            guardarMejorTiempo(tiempo, movimientos);
            mostrarMejoresTiempos();

            mostrarBotonReiniciar();
        }
    }
}

function obtenerCeldaVacia() {
    for (let i = 1; i <= 9; i++) {
        const celda = document.getElementById(`parte${i}`);
        if (celda.innerHTML.trim() === "") return celda;
    }
    return null;
}

function esVecina(celdaNum, celdaVacia) {
    const vaciaNum = parseInt(celdaVacia.id.replace("parte", ""), 10);

    const filaActual = Math.ceil(celdaNum / 3);
    const colActual = ((celdaNum - 1) % 3) + 1;

    const filaVacia = Math.ceil(vaciaNum / 3);
    const colVacia = ((vaciaNum - 1) % 3) + 1;

    const difFila = Math.abs(filaActual - filaVacia);
    const difCol = Math.abs(colActual - colVacia);

    return (difFila + difCol === 1);
}


function verificarVictoria() {
    for (let i = 1; i <= 9; i++) {
        const celda = document.getElementById(`parte${i}`);
        const img = celda.querySelector('img');

        if (i === 9 && img) return false;

        if (i !== 9) {
            const fila = Math.ceil(i / 3);
            const col = ((i - 1) % 3) + 1;
            const nombreEsperado = `row-${fila}-column${col}`;
            if (!img || !img.src.includes(nombreEsperado)) {
                return false;
            }
        }
    }
    return true;
}

function guardarMejorTiempo(tiempo, movimientos) {
    let nombre = document.getElementById('nombre-jugador').value.trim();
    if (nombre === "") nombre = "Anónimo";

    let mejores = JSON.parse(localStorage.getItem('mejoresTiempos')) || [];
    mejores.push({ nombre, tiempo, movimientos, fecha: new Date().toLocaleString() });

    mejores.sort((a, b) => a.tiempo - b.tiempo);
    mejores = mejores.slice(0, 5);

    localStorage.setItem('mejoresTiempos', JSON.stringify(mejores));
}

function mostrarMejoresTiempos() {
    const contenedor = document.getElementById("ranking");
    contenedor.innerHTML = "<h3>🏆 Mejores Tiempos</h3>";
    const mejores = JSON.parse(localStorage.getItem('mejoresTiempos')) || [];

    if (mejores.length === 0) {
        contenedor.innerHTML += "<p>Aún no hay récords.</p>";
        return;
    }

    const lista = document.createElement('ol');
    mejores.forEach(record => {
        const item = document.createElement('li');
        item.textContent = `${record.nombre} - ⏱️ ${record.tiempo}s - ${record.movimientos} mov. (${record.fecha})`;
        lista.appendChild(item);
    });

    contenedor.appendChild(lista);
}


function mostrarBotonReiniciar() {
    let btn = document.getElementById("btn-reiniciar");
    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn-reiniciar";
        btn.textContent = "Volver a jugar";
        btn.addEventListener('click', () => {
            btn.remove();
            inicioJuego();
        });
        document.body.appendChild(btn);
    }
}


function guardarPartida() {
    const nombreJugador = document.getElementById("nombre-jugador");
    if (!nombreJugador) {
        alert("No se encontró el campo de nombre del jugador en el HTML.");
        return;
    }

    const estado = {
        piezas: [],
        tiempo,
        movimientos,
        jugador: nombreJugador.value.trim() || "Anónimo"
    };

    for (let i = 1; i <= 9; i++) {
        const celda = document.getElementById(`parte${i}`);
        if (!celda) continue;
        const img = celda.querySelector("img");
        estado.piezas.push(img ? img.getAttribute("src") : "");
    }

    try {
        localStorage.setItem("partidaGuardada", JSON.stringify(estado));
        document.getElementById("mensaje").textContent = "💾 Partida guardada correctamente.";
        console.log("Partida guardada:", estado);
    } catch (err) {
        console.error("Error al guardar la partida:", err);
        alert("❌ Error al guardar la partida. Revisa la consola.");
    }
}

function cargarPartida() {
    const data = localStorage.getItem("partidaGuardada");
    if (!data) {
        document.getElementById("mensaje").textContent = "⚠️ No hay ninguna partida guardada.";
        return;
    }

    let estado;
    try {
        estado = JSON.parse(data);
    } catch (err) {
        console.error("Error al leer la partida:", err);
        alert("❌ Error al cargar la partida. Revisa la consola.");
        return;
    }

    for (let i = 1; i <= 9; i++) {
        const celda = document.getElementById(`parte${i}`);
        if (!celda) continue;
        const src = estado.piezas[i - 1];
        celda.innerHTML = src ? `<img src="${src}">` : "";
    }

    tiempo = estado.tiempo || 0;
    movimientos = estado.movimientos || 0;
    document.getElementById("nombre-jugador").value = estado.jugador || "Anónimo";
    document.getElementById("contador-tiempo").textContent = `Tiempo: ${tiempo} s`;
    document.getElementById("contador-mov").textContent = `Movimientos: ${movimientos}`;

    if (temporizador) clearInterval(temporizador);
    temporizador = setInterval(() => {
        tiempo++;
        document.getElementById("contador-tiempo").textContent = `Tiempo: ${tiempo} s`;
    }, 1000);

    juegoTerminado = false;
    document.getElementById("mensaje").textContent = "🔄 Partida cargada con éxito. ¡Sigue jugando!";
    console.log("Partida cargada:", estado);
}


